The client library is still under development, and has yet to be finalized.

It should be primarily used for writing tests for users of the
ServerRequestInterface and HTTPServerInterface APIs to verify basic
functionality, and the current state should be considered experimental.
